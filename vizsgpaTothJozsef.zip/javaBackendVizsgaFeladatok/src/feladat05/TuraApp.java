package feladat05;

public class TuraApp {

	public static void main(String[] args) {
	
		TuraUtvonalakFoFrame foAblak = new TuraUtvonalakFoFrame();
		foAblak.getFoFrame().setVisible(true);
		
	}

}
