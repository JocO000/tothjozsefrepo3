package teszt02;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import feladat02.Ital;

class ItalTeszt {

	@Test
	void konvertTeszt() {
		
		Ital italObj = new Ital("általános ital", "Italgyártó RT", 10);
		double elvartEredmeny = 100;
		
		assertEquals(elvartEredmeny, italObj.konvert("centi"));
		
	}
	

}
