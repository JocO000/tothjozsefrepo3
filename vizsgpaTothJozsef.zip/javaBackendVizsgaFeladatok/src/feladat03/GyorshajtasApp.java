package feladat03;


public class GyorshajtasApp {

	public static void main(String[] args) {
		
		Adatkezeles adatObj = new Adatkezeles();

		
	}

}
