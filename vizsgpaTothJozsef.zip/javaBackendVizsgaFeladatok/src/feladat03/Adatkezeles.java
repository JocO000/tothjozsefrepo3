package feladat03;


import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;


public class Adatkezeles {
	
	
	public Map<String, Integer> adatBeker() {
		
		Map<String, Integer> gyorshajtok = new HashMap<String, Integer>();
		
		Scanner sc = new Scanner(System.in);
	
		String rendszam;
		do {
			
			System.out.print("Írja be a gyorshajtó jármű rendszámát (vagy ha nincs több, akkor azt, hogy \"vége\"): ");
			rendszam = sc.nextLine();
			

				
				if (gyorshajtok.containsKey(rendszam)) {
					
					gyorshajtok.replace(rendszam, gyorshajtok.get(rendszam)+1);
					
				}
				else {
					
					gyorshajtok.put(rendszam, 1);
					
				}
				

			
		}while(!rendszam.equals("vége"));
		
		sc.close();
		
		return gyorshajtok;
		
	}
	

}
