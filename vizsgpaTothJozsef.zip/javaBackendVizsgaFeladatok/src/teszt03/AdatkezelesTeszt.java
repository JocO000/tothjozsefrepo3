package teszt03;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.Test;

import feladat03.Adatkezeles;

class AdatkezelesTeszt {

	@Test
	void adatBekerTeszt() {
		
		Adatkezeles adatObj = new Adatkezeles();
		
		assertFalse(adatObj.adatBeker().containsKey("vége"));
		
	}
	
	

}
