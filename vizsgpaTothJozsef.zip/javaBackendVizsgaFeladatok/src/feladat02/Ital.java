package feladat02;

public class Ital {

	private String italMegnevezese;
	private String italGyartoja;
	private double urtartalomDeciliter;

	public Ital(String italMegnevezese, String italGyartoja, double urtartalomDeciliter) {
		this.italMegnevezese = italMegnevezese;
		this.italGyartoja = italGyartoja;
		this.urtartalomDeciliter = urtartalomDeciliter;
	}

	public double konvert(String mertekegyseg) {
		if (mertekegyseg.equals("liter")) {
			
			return urtartalomDeciliter / 10.0;
			
		} else if (mertekegyseg.equals("centi")) {
			
			return urtartalomDeciliter * 10;
			
		} else {
			throw new IllegalArgumentException("nem megfelelő mértékegység");
		}
		

	} 

}
