package feladat02;

public class ItalRaktarApp {

	public static void main(String[] args) {
		
		
		
		

	}

}
