package feladat01;

import java.util.Scanner;

public class BmiIndexApp {
	
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		
		
		System.out.println("Kérem a testsúlyát(kg): ");
		double suly = sc.nextDouble();
		
		System.out.println("Kérem a magassságát(m): ");
		double magassag = sc.nextDouble();
		
		double index = kalkulal(suly,magassag);
		
		System.out.println("Az ön testömeg indexe: " + index);
		
		String besorolas = ertekeles(index);
		
		System.out.println("Az ön besorolása: " + besorolas);

		
		sc.close(); 
		
		
	}
	
	public static String ertekeles(double index) {
        if (index >= 25) {
            return "normál testsúlyhoz képest túlsúlyos";
        } else if (index <= 18.5) {
            return "normál testsúlyhoz képest sovány";
        } else {
            return "normál testsúlyú";
        } 
    }
	

	public static double kalkulal(double suly, double magassag) {
		
		return suly / (magassag * magassag) ;
		
	}
	

}
