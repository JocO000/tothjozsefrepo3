package teszt04;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import feladat04.Berlet;


class BerletTeszt {

	@Test
	void lejartTeszt() {
		
		Berlet berletObj = new Berlet("B00001","Teszt Elek","1201 Budapest",2020);
		
		assertTrue(berletObj.lejart());
		
		
	}
	

}
