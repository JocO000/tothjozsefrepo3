package feladat04;

import java.time.LocalDate;

public class Berlet {
	
	
	private String azonosito;
	private String nev;
	private String cim;
	private int lejaratiEv;
	
	
	public Berlet(String azonosito, String nev, String cim, int lejaratiEv) {
		this.azonosito = azonosito;
		this.nev = nev;
		this.cim = cim;
		this.lejaratiEv = lejaratiEv;
	}
	
	
	
	public boolean lejart() {
		
		if (lejaratiEv < LocalDate.now().getMonthValue() ) {
			
			return true;
			
		}
		return false;
		
	}

	

}
