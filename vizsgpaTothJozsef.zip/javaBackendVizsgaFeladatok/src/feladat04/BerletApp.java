package feladat04;



public class BerletApp {

	public static void main(String[] args) {
		
		FajlKezeles fajlObj = new FajlKezeles();
		
		
		
		
	}

}
