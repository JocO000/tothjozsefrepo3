package feladat04;


public class FajlKezeles {
	
	

}
